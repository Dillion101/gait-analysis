"use client";
import SectionLabel from "./SectionLabel";

const roles = [
  {
    date: "Oct 2024 – Aug 2025",
    company: "Huawei Technologies",
    location: "Osu, Accra",
    title: "Software Product Manager",
    points: [
      "Technical liaison between business stakeholders and engineering teams for enterprise platforms — AI Contact Centre (AICC) and Convergent Billing Systems (CBS).",
      "Reviewed UI flows and system behavior with developers to verify usability, clarity, and functional requirements.",
      "Led cross-functional planning using Agile principles, enabling iterative delivery and continuous improvement cycles.",
      "Ensured technical specs remained focused on maintainable, scalable implementation rather than short-term fixes.",
    ],
  },
  {
    date: "Feb 2022 – Apr 2023",
    company: "Hedge Pensions Trust",
    location: "Osu, Accra",
    title: "Systems & IT Officer",
    points: [
      "Maintained internal IT systems to ensure continuity of business-critical platforms.",
      "Designed structured backup and recovery processes to improve data security and system reliability.",
      "Collaborated with vendors and internal teams to sustain secure, stable enterprise environments.",
      "Diagnosed and resolved infrastructure and application-level issues across the network.",
    ],
  },
  {
    date: "Sep 2022 – Nov 2022",
    company: "Bank of Ghana Hospital",
    location: "Accra",
    title: "Financial Officer",
    points: [
      "Forecasted operating costs for scheduled projects in collaboration with department heads.",
      "Developed annual budgets alongside the financial director.",
      "Managed accounting data using TriMed — stocks, adjustments, and monthly accrual entries.",
    ],
  },
];

export default function Experience() {
  return (
    <section
      id="experience"
      style={{ padding: "100px 48px", borderTop: "1px solid var(--border)" }}
    >
      <SectionLabel>Experience</SectionLabel>
      <div>
        {roles.map((role, i) => (
          <div
            key={i}
            style={{
              display: "grid",
              gridTemplateColumns: "180px 1fr",
              gap: 48,
              padding: "36px 0",
              borderBottom: "1px solid var(--border)",
              borderTop: i === 0 ? "1px solid var(--border)" : "none",
            }}
            className="exp-row"
          >
            <div>
              <p style={{ fontSize: 12, letterSpacing: "0.06em", color: "var(--accent)", marginBottom: 6 }}>{role.date}</p>
              <p style={{ fontSize: 13, color: "var(--muted)", lineHeight: 1.5 }}>{role.company}<br />{role.location}</p>
            </div>
            <div>
              <h3 style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "1.2rem", fontWeight: 400,
                color: "var(--white)", marginBottom: 14,
              }}>
                {role.title}
              </h3>
              <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
                {role.points.map((pt, j) => (
                  <li key={j} style={{
                    color: "var(--muted)", fontSize: 14, lineHeight: 1.65,
                    paddingLeft: 16, position: "relative",
                  }}>
                    <span style={{ position: "absolute", left: 0, color: "var(--border-light)" }}>—</span>
                    {pt}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @media (max-width: 860px) {
          .exp-row { grid-template-columns: 1fr !important; gap: 10px !important; }
          #experience { padding: 72px 24px !important; }
        }
      `}</style>
    </section>
  );
}
