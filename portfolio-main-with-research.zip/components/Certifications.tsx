"use client";
import Image from "next/image";
import SectionLabel from "./SectionLabel";

const credentials = [
  {
    logo: "/ug-logo.png",
    name: "BSc. Computer Science",
    issuer: "University of Ghana, Legon",
    detail: "Graduated February 2025",
    link: null,
  },
  {
    logo: "/google-logo.png",
    name: "Google Project Management Professional Certificate",
    issuer: "Coursera · Google",
    detail: "Issued January 2026 · Agile Specialization",
    link: "https://www.credly.com/go/BmsYrt8w",
  },
];

export default function Certifications() {
  return (
    <section
      id="certifications"
      style={{ padding: "100px 48px", borderTop: "1px solid var(--border)" }}
    >
      <SectionLabel>Credentials</SectionLabel>
      <h2 style={{
        fontFamily: "'Instrument Serif', serif",
        fontSize: "clamp(1.8rem, 3vw, 2.6rem)",
        fontWeight: 400, color: "var(--white)",
        marginBottom: 48,
      }}>
        Education &amp; Certifications.
      </h2>

      <div style={{ display: "flex", flexDirection: "column", gap: 16, maxWidth: 660 }}>
        {credentials.map((c, i) => (
          <div
            key={i}
            style={{
              display: "flex", alignItems: "center", gap: 28,
              padding: "28px 32px",
              border: "1px solid var(--border)",
              borderRadius: 2,
              background: "var(--surface)",
              transition: "border-color 0.2s",
            }}
            className="cert-card"
            onMouseEnter={e => (e.currentTarget.style.borderColor = "var(--accent-dim)")}
            onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--border)")}
          >
            <div style={{
              width: 52, height: 52, flexShrink: 0,
              display: "flex", alignItems: "center", justifyContent: "center",
              overflow: "hidden", borderRadius: 4,
            }}>
              <Image
                src={c.logo}
                alt={c.issuer}
                width={52}
                height={52}
                style={{ objectFit: "contain", width: "100%", height: "100%" }}
              />
            </div>
            <div>
              <h3 style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "1.05rem", fontWeight: 400, color: "var(--white)", marginBottom: 5,
              }}>
                {c.name}
              </h3>
              <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: 2 }}>{c.issuer}</p>
              <p style={{ fontSize: 12, color: "var(--muted)", opacity: 0.7 }}>{c.detail}</p>
              {c.link && (
                <a
                  href={c.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    color: "var(--accent)", fontSize: 12,
                    textDecoration: "none", letterSpacing: "0.06em",
                    marginTop: 8, display: "inline-flex", alignItems: "center", gap: 5,
                  }}
                  onMouseEnter={e => (e.currentTarget.style.color = "var(--white)")}
                  onMouseLeave={e => (e.currentTarget.style.color = "var(--accent)")}
                >
                  Verify credential ↗
                </a>
              )}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @media (max-width: 860px) { #certifications { padding: 72px 24px !important; } }
      `}</style>
    </section>
  );
}
