"use client";
import SectionLabel from "./SectionLabel";

const skillGroups = [
  {
    label: "Frontend",
    skills: ["React.js", "Next.js", "TypeScript", "Tailwind CSS", "Figma / UI·UX", "Vite"],
  },
  {
    label: "Backend & Data",
    skills: ["Node.js", "Flask", "Go / Fiber", "Laravel", "PostgreSQL", "MySQL", "Redis", "REST APIs", "Microservices"],
  },
  {
    label: "ML & Research",
    skills: ["Python", "CNN / DenseNet / ResNet", "SVM", "Feature Engineering", "Data Processing"],
  },
  {
    label: "Infrastructure",
    skills: ["Git / CI·CD", "Amazon S3", "Postman", "Arduino / IoT", "Linux"],
  },
];

export default function About() {
  return (
    <section
      id="about"
      style={{
        padding: "100px 48px",
        borderTop: "1px solid var(--border)",
      }}
    >
      <SectionLabel>About</SectionLabel>
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "72px",
        alignItems: "start",
      }} className="about-grid">

        <div>
          <h2 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: "clamp(1.8rem, 3vw, 2.6rem)",
            fontWeight: 400, color: "var(--white)",
            lineHeight: 1.15, marginBottom: 24,
          }}>
            Full-stack developer<br />with a research edge.
          </h2>
          {[
            "Three-plus years working with JavaScript frameworks, building web applications and tackling machine learning problems. I got into software through curiosity — it stuck because there's always something harder to figure out.",
            "My work spans frontend engineering, backend APIs, embedded systems, and deep learning research. I've shipped things people use and published research that improved on existing models.",
            "BSc. Computer Science from the University of Ghana. I'm not looking to announce availability — I'm interested in people building something worth building.",
          ].map((p, i) => (
            <p key={i} style={{ color: "var(--muted)", lineHeight: 1.8, fontSize: 15, marginBottom: i < 2 ? 16 : 0 }}>{p}</p>
          ))}
        </div>

        <div style={{ paddingTop: 4 }}>
          {skillGroups.map((group) => (
            <div key={group.label} style={{ marginBottom: 32 }}>
              <p style={{
                fontSize: 11, letterSpacing: "0.18em",
                textTransform: "uppercase", color: "var(--accent)", marginBottom: 14,
              }}>
                {group.label}
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                {group.skills.map((s) => (
                  <span key={s} style={{
                    padding: "5px 12px",
                    border: "1px solid var(--border-light)",
                    color: "var(--muted)", fontSize: 12,
                    borderRadius: 2, letterSpacing: "0.03em",
                  }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 860px) {
          .about-grid { grid-template-columns: 1fr !important; gap: 48px !important; }
          #about { padding: 72px 24px !important; }
        }
      `}</style>
    </section>
  );
}
