"use client";
import SectionLabel from "./SectionLabel";

const projects = [
  {
    num: "01",
    title: "Pharmacy Management System",
    desc: "Full-stack web application for pharmacy operations. Built a responsive, component-based frontend with React.js and Tailwind CSS, integrated with Flask RESTful APIs for inventory management, transactions, and business workflows.",
    tags: [
      "React.js",
      "Tailwind CSS",
      "Flask",
      "REST API",
      "PostgreSQL",
      "Git",
    ],
    period: "Jan – Nov 2024",
  },
  {
    num: "02",
    title: "Gait Silhouette Analysis — Deep Learning",
    desc: "University of Ghana research comparing five silhouette representations with DenseNet and ResNet. We proposed DEWGI and enhanced GaitSTAR, increasing its recorded best holdout accuracy from 94.91% to 98.71%.",
    tags: [
      "DenseNet",
      "ResNet",
      "Python",
      "Deep Learning",
      "Pattern Recognition",
    ],
    period: "Nov 2023 – Jan 2025",
    href: "/research/",
  },
  {
    num: "03",
    title: "Brain Cancer Image Classification",
    desc: "Developed machine learning models to classify cancerous brain images using Kaggle datasets. Applied SVM and CNN architectures with thorough data preprocessing and model optimization for accuracy.",
    tags: ["CNN", "SVM", "Python", "Kaggle", "ML"],
    period: "2023",
  },
  {
    num: "04",
    title: "Legacy E-Commerce Refactor (Laravel)",
    desc: "Modernized a legacy Laravel e-commerce platform — rewrote controllers, routes, and views to current framework conventions, resolved dependency conflicts, hardened security, and improved code maintainability throughout.",
    tags: ["PHP", "Laravel", "Composer", "Refactoring", "Security"],
    period: "Sep 2025 – Present",
  },
  {
    num: "05",
    title: "Smart Bin Monitoring System",
    desc: "IoT system using an ultrasonic sensor to monitor bin fill levels and a GSM module to dispatch disposal alerts. Later extended with a frontend dashboard for real-time bin level visualization.",
    tags: ["Arduino", "GSM Module", "Ultrasonic Sensor", "IoT", "Embedded C"],
    period: "2022",
  },
  {
    num: "06",
    title: "Financial Accounting App",
    desc: "Django-based personal finance tool for tracking expenses and supporting budget planning. Includes expense categorization, budget targets, and analysis views to support financial decision-making.",
    tags: ["Django", "Python", "MySQL"],
    period: "2023",
  },
];

export default function Projects() {
  return (
    <section
      id="projects"
      style={{ padding: "100px 48px", borderTop: "1px solid var(--border)" }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-end",
          marginBottom: 0,
        }}
        className="proj-header"
      >
        <div>
          <SectionLabel>Projects</SectionLabel>
          <h2
            style={{
              fontFamily: "'Instrument Serif', serif",
              fontSize: "clamp(1.8rem, 3vw, 2.6rem)",
              fontWeight: 400,
              color: "var(--white)",
              marginTop: -20,
              marginBottom: 52,
            }}
          >
            Selected work.
          </h2>
        </div>
        <a
          href="https://github.com/Dillion101/"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            padding: "11px 22px",
            background: "transparent",
            color: "var(--muted)",
            fontSize: 12,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            textDecoration: "none",
            border: "1px solid var(--border-light)",
            borderRadius: 2,
            transition: "all 0.2s",
            marginBottom: 52,
            flexShrink: 0,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = "var(--accent-dim)";
            e.currentTarget.style.color = "var(--text)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = "var(--border-light)";
            e.currentTarget.style.color = "var(--muted)";
          }}
        >
          <svg
            aria-hidden="true"
            focusable="false"
            viewBox="0 0 24 24"
            style={{
              width: 14,
              height: 14,
              fill: "currentColor",
              flexShrink: 0,
            }}
          >
            <path d="M12 .5C5.73.5.5 5.74.5 12.02c0 5.11 3.29 9.44 7.86 10.97.58.11.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.88-1.54-3.88-1.54-.53-1.35-1.29-1.71-1.29-1.71-1.05-.72.08-.71.08-.71 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.72-1.55-2.55-.29-5.23-1.28-5.23-5.69 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18.92-.26 1.9-.39 2.88-.39.98 0 1.96.13 2.88.39 2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.18 1.84 1.18 3.1 0 4.42-2.69 5.39-5.25 5.67.41.36.78 1.07.78 2.16 0 1.56-.01 2.81-.01 3.19 0 .31.21.68.8.56 4.56-1.53 7.85-5.86 7.85-10.97C23.5 5.74 18.27.5 12 .5z" />
          </svg>
          GitHub ↗
        </a>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "1px",
          background: "var(--border)",
          border: "1px solid var(--border)",
          borderRadius: 2,
          overflow: "hidden",
        }}
        className="proj-grid"
      >
        {projects.map((p) => (
          <div
            key={p.num}
            style={{
              background: "var(--bg)",
              padding: "32px 28px",
              transition: "background 0.2s",
              position: "relative",
              overflow: "hidden",
            }}
            className="proj-card"
            onMouseEnter={(e) =>
              (e.currentTarget.style.background = "var(--surface)")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.background = "var(--bg)")
            }
          >
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                height: 2,
                background: "var(--accent)",
                transform: "scaleX(0)",
                transformOrigin: "left",
                transition: "transform 0.3s ease",
              }}
              className="card-bar"
            />
            <p
              style={{
                fontSize: 11,
                letterSpacing: "0.14em",
                color: "var(--border-light)",
                marginBottom: 20,
              }}
            >
              {p.num}
            </p>
            <h3
              style={{
                fontFamily: "'Instrument Serif', serif",
                fontSize: "1.1rem",
                fontWeight: 400,
                color: "var(--white)",
                marginBottom: 12,
                lineHeight: 1.3,
              }}
            >
              {p.title}
            </h3>
            <p
              style={{
                color: "var(--muted)",
                fontSize: 13.5,
                lineHeight: 1.65,
                marginBottom: 20,
              }}
            >
              {p.desc}
            </p>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: 6,
                marginBottom: 16,
              }}
            >
              {p.tags.map((t) => (
                <span
                  key={t}
                  style={{
                    fontSize: 11,
                    letterSpacing: "0.06em",
                    color: "var(--accent-dim)",
                    border: "1px solid #241e18",
                    padding: "3px 8px",
                    borderRadius: 2,
                  }}
                >
                  {t}
                </span>
              ))}
            </div>
            <p
              style={{
                fontSize: 11,
                color: "var(--muted)",
                letterSpacing: "0.06em",
                opacity: 0.7,
              }}
            >
              {p.period}
            </p>
            {p.href && (
              <a
                href={p.href}
                style={{
                  display: "inline-flex",
                  marginTop: 18,
                  color: "var(--accent)",
                  fontSize: 11,
                  letterSpacing: "0.09em",
                  textTransform: "uppercase",
                  textDecoration: "none",
                }}
              >
                Explore research case study ↗
              </a>
            )}
          </div>
        ))}
      </div>

      <style>{`
        .proj-card:hover .card-bar { transform: scaleX(1) !important; }
        @media (max-width: 1024px) { .proj-grid { grid-template-columns: repeat(2,1fr) !important; } }
        @media (max-width: 640px) { .proj-grid { grid-template-columns: 1fr !important; } }
        @media (max-width: 860px) {
          #projects { padding: 72px 24px !important; }
          .proj-header { flex-direction: column !important; align-items: flex-start !important; }
        }
      `}</style>
    </section>
  );
}
