"use client";
export default function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{
      fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase",
      color: "var(--accent)", marginBottom: 52,
      display: "flex", alignItems: "center", gap: 14,
    }}>
      {children}
      <span style={{ flex: 1, height: 1, background: "var(--border)", maxWidth: 72 }} />
    </p>
  );
}
