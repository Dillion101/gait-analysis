"use client";
export default function Footer() {
  return (
    <footer
      style={{
        borderTop: "1px solid var(--border)",
        padding: "24px 48px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
      className="footer"
    >
      <p
        style={{ color: "var(--muted)", fontSize: 12, letterSpacing: "0.06em" }}
      >
        © 2026 Dillion Amartey
      </p>
      <div style={{ display: "flex", gap: 24 }}>
        {[
          {
            label: "GitHub",
            href: "https://github.com/Dillion101/",
            icon: (
              <svg
                aria-hidden="true"
                focusable="false"
                viewBox="0 0 24 24"
                style={{
                  width: 16,
                  height: 16,
                  fill: "currentColor",
                  flexShrink: 0,
                }}
              >
                <path d="M12 .5C5.73.5.5 5.74.5 12.02c0 5.11 3.29 9.44 7.86 10.97.58.11.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.88-1.54-3.88-1.54-.53-1.35-1.29-1.71-1.29-1.71-1.05-.72.08-.71.08-.71 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.72-1.55-2.55-.29-5.23-1.28-5.23-5.69 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18.92-.26 1.9-.39 2.88-.39.98 0 1.96.13 2.88.39 2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.18 1.84 1.18 3.1 0 4.42-2.69 5.39-5.25 5.67.41.36.78 1.07.78 2.16 0 1.56-.01 2.81-.01 3.19 0 .31.21.68.8.56 4.56-1.53 7.85-5.86 7.85-10.97C23.5 5.74 18.27.5 12 .5z" />
              </svg>
            ),
          },
          {
            label: "LinkedIn",
            href: "https://www.linkedin.com/in/dillion-amartey-85951527b",
            icon: (
              <svg
                aria-hidden="true"
                focusable="false"
                viewBox="0 0 24 24"
                style={{
                  width: 16,
                  height: 16,
                  fill: "currentColor",
                  flexShrink: 0,
                }}
              >
                <path d="M22.225 0H1.771C.792 0 0 .774 0 1.727v20.545C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.273V1.727C24 .774 23.2 0 22.222 0h.003zM7.114 20.452H3.56V9h3.554v11.452zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.062 2.062 0 112.063 2.065zm15.11 13.019h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.264 2.37 4.264 5.455v6.286z" />
              </svg>
            ),
          },
          {
            label: "Email",
            href: "mailto:damartey008@gmail.com",
            icon: (
              <svg
                aria-hidden="true"
                focusable="false"
                viewBox="0 0 24 24"
                style={{
                  width: 16,
                  height: 16,
                  fill: "currentColor",
                  flexShrink: 0,
                }}
              >
                <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z" />
              </svg>
            ),
          },
        ].map((l) => (
          <a
            key={l.label}
            href={l.href}
            aria-label={l.label}
            title={l.label}
            target={l.href.startsWith("http") ? "_blank" : undefined}
            rel="noopener noreferrer"
            style={{
              display: "inline-flex",
              alignItems: "center",
              color: "var(--muted)",
              textDecoration: "none",
              letterSpacing: "0.06em",
              transition: "color 0.2s",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted)")}
          >
            {l.icon}
          </a>
        ))}
      </div>
      <style>{`
        @media (max-width: 640px) {
          .footer { flex-direction: column !important; gap: 14px !important; text-align: center; padding: 20px 24px !important; }
        }
      `}</style>
    </footer>
  );
}
