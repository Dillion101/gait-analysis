"use client";
import Image from "next/image";

export default function Hero() {
  return (
    <section
      id="hero"
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        padding: "120px 48px 80px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Grid background */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 0,
          backgroundImage:
            "linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
          opacity: 0.22,
          maskImage:
            "radial-gradient(ellipse 80% 80% at 40% 50%, black 20%, transparent 100%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 80% 80% at 40% 50%, black 20%, transparent 100%)",
        }}
      />

      <div
        style={{
          position: "relative",
          zIndex: 1,
          width: "100%",
          maxWidth: 1200,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-end",
          gap: 48,
        }}
      >
        {/* Left: text */}
        <div style={{ flex: 1, maxWidth: 680 }}>
          <p
            style={{
              fontSize: 11,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "var(--accent)",
              marginBottom: 28,
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <span
              style={{
                display: "inline-block",
                width: 36,
                height: 1,
                background: "var(--accent)",
              }}
            />
            Software Developer · Accra, Ghana
          </p>

          <h1
            style={{
              fontFamily: "'Instrument Serif', serif",
              fontSize: "clamp(2.8rem, 6vw, 5rem)",
              lineHeight: 1.05,
              color: "var(--white)",
              fontWeight: 400,
              marginBottom: 32,
            }}
          >
            Building things that
            <br />
            <em style={{ fontStyle: "italic", color: "var(--accent)" }}>
              work &amp; hold together.
            </em>
          </h1>

          <p
            style={{
              maxWidth: 500,
              color: "var(--muted)",
              fontSize: 16,
              lineHeight: 1.75,
              marginBottom: 48,
            }}
          >
            I work across the full stack — from interfaces people actually enjoy
            using, to machine learning models and systems that stay reliable
            under pressure. Currently interested in meaningful collaborations.
          </p>

          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <a
              href="#projects"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                padding: "13px 28px",
                background: "var(--accent)",
                color: "var(--bg)",
                fontFamily: "'DM Sans', sans-serif",
                fontSize: 12,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                textDecoration: "none",
                borderRadius: 2,
                fontWeight: 500,
                transition: "background 0.2s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "var(--white)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "var(--accent)")
              }
            >
              View Projects
            </a>
            <a
              href="#contact"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                padding: "13px 28px",
                background: "transparent",
                color: "var(--muted)",
                fontFamily: "'DM Sans', sans-serif",
                fontSize: 12,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                textDecoration: "none",
                border: "1px solid var(--border-light)",
                borderRadius: 2,
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "var(--accent-dim)";
                e.currentTarget.style.color = "var(--text)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "var(--border-light)";
                e.currentTarget.style.color = "var(--muted)";
              }}
            >
              Get in touch
            </a>
          </div>
        </div>

        {/* Right: photo with blend */}
        <div
          style={{
            width: 220,
            height: 300,
            flexShrink: 0,
            position: "relative",
            borderRadius: 2,
            overflow: "hidden",
          }}
          className="photo-box"
        >
          <Image
            src="/header.jpg"
            alt="Dillion Amartey"
            fill
            style={{ objectFit: "cover", objectPosition: "center top" }}
            priority
          />
          {/* fade bottom into bg */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 2,
              background:
                "linear-gradient(to bottom, transparent 40%, #0d0d0d 100%)",
            }}
          />
          {/* fade left edge into bg */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 2,
              background:
                "linear-gradient(to right, #0d0d0d 0%, transparent 30%)",
            }}
          />
          {/* fade right edge */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 2,
              background:
                "linear-gradient(to left, #0d0d0d 0%, transparent 30%)",
            }}
          />
          {/* fade top */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 2,
              background:
                "linear-gradient(to top, transparent 60%, #0d0d0d 100%)",
            }}
          />
        </div>
      </div>

      <style>{`
        @media (max-width: 860px) {
          #hero { padding: 110px 24px 60px !important; }
          #hero > div { flex-direction: column !important; align-items: flex-start !important; }
          .photo-box { width: 100% !important; height: auto !important; aspect-ratio: 4 / 5 !important; }
        }
      `}</style>
    </section>
  );
}
